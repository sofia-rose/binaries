let push_frame () = ()
let pop_frame () = ()
let salloc a = ref a
let op_Bang a = !a
let get () = ()
