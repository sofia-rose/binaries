=============================
Relevant files for metatheory
=============================

- metatheory_language.txt
  + (metatheory for the language without reify-reflect)
    
- metatheory_language_indexed.txt
  + (metatheory for the language with reify-reflect)
    
- metatheory_logic.txt
  + (natural deduction, sequent calculus, proof theory)
    
- metatheory_normalisation.txt
  + (normalisation proof for metatheory_language.txt)
